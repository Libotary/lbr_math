#lbr加法操作
def lbr_add(a,b):
    return a + b


#lbr减法操作
def lbr_sub(a,b):
    return a - b