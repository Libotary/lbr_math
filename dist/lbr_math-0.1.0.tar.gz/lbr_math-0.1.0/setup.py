from setuptools import setup

setup(
    name="lbr_math",
    version="0.1.0",
    packages=['lbr_math'],
    install_requires=[

    ],
)